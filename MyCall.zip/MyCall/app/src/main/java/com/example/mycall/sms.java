package com.example.mycall;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class sms extends AppCompatActivity {
    EditText phone,text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        Button button1 =(Button) findViewById(R.id.call);
        Button button2 =(Button) findViewById(R.id.sent);
        phone =(EditText) findViewById((R.id.phonenumber));
        text =(EditText) findViewById((R.id.SMS));
        button1.setOnClickListener(new button1click1());
        button2.setOnClickListener(new button1click2());
    }
   public class button1click1 implements View.OnClickListener {
        public void onClick(View v)
        {
            String number = phone.getText().toString();
            Intent intent=new Intent();
            intent.setAction(Intent.ACTION_CALL);
            intent.setData( Uri.parse("tel:" + number));
            startActivity(intent);

        }
    }
    public class button1click2 implements View.OnClickListener {
        public void onClick(View v)
        {
            String mess = text.getText().toString();
            String number = phone.getText().toString();
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(number, null, mess, null, null);

        }
    }
}