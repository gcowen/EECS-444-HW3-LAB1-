package com.example.mycall;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.view.*;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.call_layout);
        Button button1 =(Button) findViewById(R.id.button1);
        Button button2 =(Button) findViewById(R.id.swichtoSMS);
        editText =(EditText) findViewById((R.id.phonenumber_id));
        button1.setOnClickListener(new button1click1());
        button2.setOnClickListener(new button1click2());
    }
    public class button1click1 implements View.OnClickListener {
        public void onClick(View v)
        {
            String number = editText.getText().toString();
            Intent intent=new Intent();
            intent.setAction(Intent.ACTION_CALL);
            intent.setData( Uri.parse("tel:" + number));
            startActivity(intent);

        }
    }
    public class button1click2 implements View.OnClickListener {
        public void onClick(View v)
        {
           Intent i=new Intent(MainActivity.this,sms.class);
            startActivity(i);
        }
    }
}
