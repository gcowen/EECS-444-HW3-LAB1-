package com.example.maldroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button invoke=(Button) findViewById(R.id.invoke);
        invoke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ComponentName componentName =new ComponentName("com.example.mycall","com.example.mycall.MainActivity");
                Intent intent=new Intent();
                intent.setComponent(componentName);
                startActivity(intent);
            }
        });
    }
}
